from flask import Flask, render_template, request, redirect, url_for
# from werkzeug.utils import secure_filename
from ultralytics import YOLO

app = Flask(__name__)

# Configure the upload folder and allowed extensions
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/detect', methods=['POST'])
def detect():
    model = YOLO('best2.pt')
    model.predict(source = 0, imgsz = 640, conf = 0.6, show = True)

if __name__== '__main__':
    app.run(debug=True)